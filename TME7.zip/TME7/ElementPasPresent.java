public class ElementPasPresent extends Exception{
	public ElementPasPresent(String m){
		super(m);
	}
}
