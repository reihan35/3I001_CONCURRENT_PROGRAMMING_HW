package Exo11;

import java.util.Random;

public class ReponseRequete {
	private int numReq;
	private Client c;
	private Random r = new Random();
	private int val;
	
	public ReponseRequete(int numReq, Client c){
		this.numReq=numReq;
		this.c=c;
		val = r.nextInt(10);
	}
	
	public String toString(){
		return "Requête " + numReq + " du client " + c.getId() + " traitée : " + val;
	}
}
